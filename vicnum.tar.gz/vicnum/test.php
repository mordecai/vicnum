<?php phpinfo()  ; ?>
